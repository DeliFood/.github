package ac.id.del.listview

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toNav()
    }

    private fun toNav() {
        startActivity(Intent(this, Navigation::class.java))
    }

}